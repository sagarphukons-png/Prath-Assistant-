# Keep app classes
-keep class com.parth.assistant.** { *; }

# Keep Android speech classes
-keep class android.speech.** { *; }

# Keep TTS
-keep class android.speech.tts.** { *; }

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
