package com.parth.assistant;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/**
 * Lightweight rule-based command processor.
 * No AI models, no cloud APIs - pure string matching.
 * RAM footprint: <2MB
 */
public class AssistantEngine {

    private final Context context;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean flashlightOn = false;

    // Joke list stored in memory (tiny footprint)
    private static final String[] JOKES = {
        "Why don't scientists trust atoms? Because they make up everything!",
        "I told my wife she was drawing her eyebrows too high. She looked surprised.",
        "Why did the scarecrow win an award? Because he was outstanding in his field!",
        "I'm reading a book about anti-gravity. It's impossible to put down!",
        "Why don't eggs tell jokes? They'd crack each other up!",
        "What do you call fake spaghetti? An impasta!",
        "Why did the bicycle fall over? Because it was two-tired!",
        "What's a computer's favorite snack? Microchips!",
        "Why did the math book look so sad? Because it had too many problems.",
        "What do you call a fish without eyes? A fsh!"
    };

    private final Random random = new Random();

    public AssistantEngine(Context context) {
        this.context = context;
        initCamera();
    }

    private void initCamera() {
        try {
            cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager != null) {
                String[] ids = cameraManager.getCameraIdList();
                if (ids.length > 0) cameraId = ids[0];
            }
        } catch (Exception e) {
            // Camera not available - handle gracefully
        }
    }

    public static class CommandResult {
        public final String response;
        public final Runnable action;

        CommandResult(String response, Runnable action) {
            this.response = response;
            this.action = action;
        }

        CommandResult(String response) {
            this(response, null);
        }
    }

    /**
     * Main command processing - pure string matching, O(n) time, minimal memory
     */
    public CommandResult processCommand(String input) {
        if (input == null || input.trim().isEmpty()) {
            return new CommandResult("I didn't catch that. Could you please repeat?");
        }

        String cmd = input.toLowerCase(Locale.getDefault()).trim();

        // --- App Launch Commands ---
        if (matches(cmd, "open youtube", "youtube", "play youtube")) {
            return new CommandResult("Opening YouTube for you!", () -> openApp(
                "com.google.android.youtube",
                "https://www.youtube.com"
            ));
        }

        if (matches(cmd, "open camera", "camera", "take photo", "take picture")) {
            return new CommandResult("Opening the camera!", () -> openCamera());
        }

        if (matches(cmd, "open maps", "google maps", "open navigation", "maps")) {
            return new CommandResult("Opening Google Maps!", () -> openApp(
                "com.google.android.apps.maps",
                "https://maps.google.com"
            ));
        }

        if (matches(cmd, "open browser", "open chrome", "chrome", "browser", "internet")) {
            return new CommandResult("Opening your browser!", () -> openBrowser());
        }

        if (matches(cmd, "open settings", "settings", "system settings")) {
            return new CommandResult("Opening Settings!", () -> openSettings());
        }

        if (matches(cmd, "open calculator", "calculator", "calculate")) {
            return new CommandResult("Opening Calculator!", () -> openApp(
                "com.google.android.calculator",
                null
            ));
        }

        if (matches(cmd, "open gallery", "gallery", "photos", "open photos")) {
            return new CommandResult("Opening your gallery!", () -> openGallery());
        }

        // --- Flashlight Commands ---
        if (matches(cmd, "turn on flashlight", "flashlight on", "torch on", "enable flashlight", "switch on flashlight")) {
            return new CommandResult("Turning on the flashlight!", () -> setFlashlight(true));
        }

        if (matches(cmd, "turn off flashlight", "flashlight off", "torch off", "disable flashlight", "switch off flashlight")) {
            return new CommandResult("Turning off the flashlight!", () -> setFlashlight(false));
        }

        if (matches(cmd, "flashlight", "torch")) {
            boolean newState = !flashlightOn;
            return new CommandResult(newState ? "Turning on the flashlight!" : "Turning off the flashlight!",
                () -> setFlashlight(newState));
        }

        // --- Music Commands ---
        if (matches(cmd, "play music", "music", "play songs", "play song", "open music")) {
            return new CommandResult("Playing your music!", () -> playMusic());
        }

        // --- Time & Date Commands ---
        if (matches(cmd, "what time is it", "time", "current time", "tell me the time", "what's the time")) {
            String time = getCurrentTime();
            return new CommandResult("It's " + time);
        }

        if (matches(cmd, "what day is it", "date", "today's date", "what date", "what's today")) {
            String date = getCurrentDate();
            return new CommandResult("Today is " + date);
        }

        // --- Alarm Commands ---
        if (matches(cmd, "set alarm", "alarm", "wake me up", "set a timer")) {
            return new CommandResult("Opening alarm settings for you!", () -> openAlarm());
        }

        // --- Entertainment ---
        if (matches(cmd, "tell a joke", "joke", "make me laugh", "say something funny")) {
            String joke = getRandomJoke();
            return new CommandResult(joke);
        }

        if (matches(cmd, "flip a coin", "coin flip", "heads or tails")) {
            String result = random.nextBoolean() ? "Heads!" : "Tails!";
            return new CommandResult("I flipped a coin... " + result);
        }

        if (matches(cmd, "roll a dice", "roll dice", "roll a die", "random number")) {
            int dice = random.nextInt(6) + 1;
            return new CommandResult("I rolled a dice and got: " + dice);
        }

        // --- Greeting Commands ---
        if (matches(cmd, "hello", "hi", "hey", "good morning", "good afternoon", "good evening", "what's up", "howdy")) {
            String greeting = getGreeting();
            return new CommandResult(greeting);
        }

        if (matches(cmd, "how are you", "how are you doing", "how do you feel")) {
            return new CommandResult("I'm running great, thanks for asking! I'm your lightweight assistant, always ready to help. How can I assist you?");
        }

        if (matches(cmd, "what can you do", "help", "commands", "what do you know", "capabilities")) {
            return new CommandResult("I can: open apps like YouTube, Camera, Maps; control your flashlight; play music; tell jokes; check time and date; set alarms; flip coins; and answer questions. Just ask!");
        }

        // --- System Info ---
        if (matches(cmd, "what's your name", "who are you", "your name")) {
            return new CommandResult("I'm parth Assistant! A lightweight, fast assistant built just for you.");
        }

        if (matches(cmd, "battery", "battery level", "how much battery")) {
            return new CommandResult("I can't directly check battery, but you can swipe down your notification bar to see battery level!");
        }

        // --- Weather (no API, direct user to app) ---
        if (matches(cmd, "weather", "temperature", "forecast", "will it rain")) {
            return new CommandResult("I don't have weather data offline. Opening your browser to check!", () -> openUrl("https://weather.com"));
        }

        // --- Goodbye ---
        if (matches(cmd, "goodbye", "bye", "see you", "exit", "quit", "close")) {
            return new CommandResult("Goodbye! See you next time. Have a great day!");
        }

        // --- Thank you ---
        if (matches(cmd, "thank you", "thanks", "thank you very much")) {
            return new CommandResult("You're welcome! Happy to help anytime.");
        }

        // Default fallback
        return new CommandResult("I heard: \"" + input + "\". I'm not sure how to help with that yet. Try: 'Open YouTube', 'Tell a joke', 'What time is it?', or say 'Help' for more commands.");
    }

    // --- Helper Methods ---

    private boolean matches(String input, String... keywords) {
        for (String keyword : keywords) {
            if (input.contains(keyword.toLowerCase(Locale.getDefault()))) {
                return true;
            }
        }
        return false;
    }

    private void openApp(String packageName, String fallbackUrl) {
        try {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return;
            }
        } catch (Exception ignored) {}

        if (fallbackUrl != null) {
            openUrl(fallbackUrl);
        } else {
            Toast.makeText(context, "App not installed", Toast.LENGTH_SHORT).show();
        }
    }

    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "Cannot open URL", Toast.LENGTH_SHORT).show();
        }
    }

    private void openCamera() {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "Camera not available", Toast.LENGTH_SHORT).show();
        }
    }

    private void openBrowser() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "No browser found", Toast.LENGTH_SHORT).show();
        }
    }

    private void openSettings() {
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "Cannot open settings", Toast.LENGTH_SHORT).show();
        }
    }

    private void openGallery() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "No gallery app found", Toast.LENGTH_SHORT).show();
        }
    }

    private void setFlashlight(boolean on) {
        if (cameraManager == null || cameraId == null) {
            Toast.makeText(context, "Flashlight not available", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            cameraManager.setTorchMode(cameraId, on);
            flashlightOn = on;
        } catch (CameraAccessException e) {
            Toast.makeText(context, "Cannot access flashlight", Toast.LENGTH_SHORT).show();
        }
    }

    private void playMusic() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setType("audio/*");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            // Try opening a music app
            openApp("com.google.android.music", null);
        }
    }

    private void openAlarm() {
        try {
            Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
            intent.putExtra(AlarmClock.EXTRA_MESSAGE, "Alarm set by parth Assistant");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "No alarm app found", Toast.LENGTH_SHORT).show();
        }
    }

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("h:mm a", Locale.getDefault());
        return sdf.format(new Date());
    }

    private String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault());
        return sdf.format(new Date());
    }

    private String getRandomJoke() {
        return JOKES[random.nextInt(JOKES.length)];
    }

    private String getGreeting() {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        String timeGreeting;
        if (hour < 12) timeGreeting = "Good morning";
        else if (hour < 17) timeGreeting = "Good afternoon";
        else timeGreeting = "Good evening";

        return timeGreeting + "! I'm parth Assistant. How can I help you today?";
    }

    public void release() {
        // Release any held resources
        if (flashlightOn) {
            setFlashlight(false);
        }
    }
}
