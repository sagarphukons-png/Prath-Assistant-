package com.parth.assistant;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;

    private SpeechRecognizer speechRecognizer;
    private AssistantEngine assistantEngine;
    private VoiceOutputManager voiceOutput;

    private ImageButton btnMic;
    private TextView tvConversation;
    private ScrollView scrollView;
    private TextView tvStatus;

    private boolean isListening = false;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        initAssistant();
        requestPermissions();

        appendMessage("parth Assistant", "Hello! I'm parth Assistant. Tap the mic button and speak a command.", false);
        appendMessage("parth Assistant", "Try: 'Open YouTube', 'Tell a joke', 'What time is it?', 'Turn on flashlight'", false);
    }

    private void initViews() {
        btnMic = findViewById(R.id.btn_mic);
        tvConversation = findViewById(R.id.tv_conversation);
        scrollView = findViewById(R.id.scroll_view);
        tvStatus = findViewById(R.id.tv_status);

        btnMic.setOnClickListener(v -> {
            if (!isListening) {
                startListening();
            } else {
                stopListening();
            }
        });
    }

    private void initAssistant() {
        assistantEngine = new AssistantEngine(this);
        voiceOutput = new VoiceOutputManager(this);
    }

    private void requestPermissions() {
        String[] permissions = {Manifest.permission.RECORD_AUDIO};
        boolean needRequest = false;
        for (String perm : permissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                needRequest = true;
                break;
            }
        }
        if (needRequest) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }

    private void startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission required", Toast.LENGTH_SHORT).show();
            requestPermissions();
            return;
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available on this device", Toast.LENGTH_LONG).show();
            return;
        }

        isListening = true;
        btnMic.setImageResource(R.drawable.ic_mic_active);
        tvStatus.setText("Listening...");
        tvStatus.setTextColor(getResources().getColor(R.color.listening_color, null));

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                uiHandler.post(() -> tvStatus.setText("Listening... speak now"));
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {
                uiHandler.post(() -> tvStatus.setText("Processing..."));
            }
            @Override
            public void onError(int error) {
                uiHandler.post(() -> {
                    isListening = false;
                    btnMic.setImageResource(R.drawable.ic_mic);
                    tvStatus.setText("Tap mic to speak");
                    tvStatus.setTextColor(getResources().getColor(R.color.status_idle, null));
                    String errorMsg = getSpeechErrorMessage(error);
                    if (error != SpeechRecognizer.ERROR_NO_MATCH) {
                        appendMessage("System", errorMsg, true);
                    }
                });
            }
            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String spokenText = matches.get(0);
                    uiHandler.post(() -> handleVoiceInput(spokenText));
                }
                uiHandler.post(() -> {
                    isListening = false;
                    btnMic.setImageResource(R.drawable.ic_mic);
                    tvStatus.setText("Tap mic to speak");
                    tvStatus.setTextColor(getResources().getColor(R.color.status_idle, null));
                });
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500);

        speechRecognizer.startListening(intent);
    }

    private void stopListening() {
        if (speechRecognizer != null) {
            speechRecognizer.stopListening();
        }
        isListening = false;
        btnMic.setImageResource(R.drawable.ic_mic);
        tvStatus.setText("Tap mic to speak");
        tvStatus.setTextColor(getResources().getColor(R.color.status_idle, null));
    }

    private void handleVoiceInput(String input) {
        appendMessage("You", input, true);

        AssistantEngine.CommandResult result = assistantEngine.processCommand(input);

        appendMessage("parth", result.response, false);
        voiceOutput.speak(result.response);

        if (result.action != null) {
            result.action.run();
        }
    }

    public void appendMessage(String sender, String message, boolean isUser) {
        uiHandler.post(() -> {
            String current = tvConversation.getText().toString();
            String newText = current.isEmpty()
                    ? sender + ": " + message
                    : current + "\n\n" + sender + ": " + message;
            tvConversation.setText(newText);
            scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
        });
    }

    private String getSpeechErrorMessage(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_NETWORK: return "Network error. Check internet connection.";
            case SpeechRecognizer.ERROR_AUDIO: return "Audio recording error.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Microphone permission denied.";
            case SpeechRecognizer.ERROR_NO_MATCH: return "Could not understand. Please try again.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Recognition service busy.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "No speech detected.";
            default: return "Speech error. Please try again.";
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        if (voiceOutput != null) {
            voiceOutput.shutdown();
        }
        if (assistantEngine != null) {
            assistantEngine.release();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isListening) {
            stopListening();
        }
    }
}
