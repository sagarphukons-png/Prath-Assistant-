package com.parth.assistant;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * Placeholder wake word service.
 * A full wake word implementation requires a dedicated tiny model like Porcupine.
 * This is kept as a stub to avoid battery drain on low-end devices.
 *
 * To enable wake word "Hey parth":
 * 1. Integrate Picovoice Porcupine (free tier, ~1MB)
 * 2. Or use VOSK offline speech recognition with keyword spotting
 *
 * For now, just use the mic button - more battery-friendly anyway!
 */
public class WakeWordService extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Stub - not running background recognition to save battery on 2GB RAM phones
        stopSelf();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
